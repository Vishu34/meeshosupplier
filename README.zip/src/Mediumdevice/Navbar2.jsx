import { NavLink } from "react-router-dom";
import { useEffect,useState } from "react";
import { BsBarChartFill, BsXLg } from "react-icons/bs";



  const Navbar2=()=>{
    const [show, setshow] = useState(false);

  const showbtn = () => {
    setshow(!show);
  };
  return (
    <>
      <div className=" d-md-block d-xl-none d-none  w-100 bg-white Navbar ">
      <div className="container d-flex justify-content-between align-items-center align-content-center" data-aos="fade-left">
      <NavLink exact to="/" className="mx-2 fw-bold my-3 mx-2 meesho">
      <img src="https://supplier.meesho.com/images/logo.svg" />
        </NavLink>
          
          

        <div className="d-flex align-items-center ">
          <div className="btn1 d-none d-md-block">
          <NavLink exact to="/loginpage" className="">
            <button id="btn1">login</button>
            </NavLink>
          </div>
          <div className="btn1 d-none d-md-block">
          <NavLink exact to="/startsell" className="">
            <button  id="btn2" className="btn2 ">start selling</button>
            </NavLink>
          </div>
          
          {show ? (
            <div className="  ">
              <button className="btn mx-3 " style={{color:"#f43397",border:"1px solid rgba(0,0,0,0.09"}} onClick={showbtn} >
              <BsXLg style={{color:"#f43397"}}/>
              </button>
            </div>
          ) : (
            <div className=" ">
              <button className="btn  mx-3" onClick={showbtn}>
              <BsBarChartFill style={{color:"#f43397"}}/>
               
              </button>
            </div>
          )}
        </div>
      </div>
      </div>
      {
            show ? (
              <div className="d-flex flex-column  mobilebtn1">
              <NavLink exact to="/sellonline" className="mx-5 meeshonavbar">
          Sell online
        </NavLink>
        <NavLink exact to="/howtowork" className="mx-5 meeshonavbar">
          How its work
        </NavLink>
        <NavLink exact to="/price" className="mx-5 meeshonavbar">
          Pricing & communication
        </NavLink>
        <NavLink exact to="/shipreturn" className="mx-5 meeshonavbar">
          Shipping & return
        </NavLink>
        <NavLink exact to="/growbusiness" className="mx-5 meeshonavbar ">
          Grow & business
        </NavLink>
        
              </div>
            ):null
          }
    </>
  );
};
export default Navbar2;