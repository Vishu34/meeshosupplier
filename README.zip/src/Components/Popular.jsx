const Popular=()=>{
return(
    <>
        

        <div className="container-fluid parent margin-auto">
        <div className="container my-3">
          <div className="row">
            <div className="col">
              <div className="mainpopular">
                <div className="popular1">
                  Popular Categories to Sell Online
                </div>
              </div>

              <div className="col online">
                <div className="onlinecontent">sell sarees online</div>
                <div className="onlinecontent">sell Jewellery online</div>
                <div className="onlinecontent">sell tshirts online</div>
                <div className="onlinecontent">sell shirts online</div>
                <div className="onlinecontent">sell watch online</div>
                <div className="onlinecontent">sell electronic online</div>
                <div className="onlinecontent">sell clothes online</div>
                <div className="onlinecontent">sell shocks online</div>
              </div>
              <div className="view">view more</div>
            </div>
          </div>
        </div>
        </div>

    </>
)
}
export default Popular;